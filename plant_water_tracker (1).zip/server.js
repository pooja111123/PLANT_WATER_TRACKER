
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const userRoutes = require('./routes/userRoutes');

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,'public')));

mongoose.connect('mongodb://127.0.0.1:27017/plant_app');

app.use('/api/user', userRoutes);

app.get('/', (req,res)=>{
    res.sendFile(path.join(__dirname,'public/index.html'));
});

app.listen(5000, ()=> console.log("Server running at http://localhost:5000"));
