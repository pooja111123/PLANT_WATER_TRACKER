
function showRegister(){document.querySelector('#loginBox').style.display='none';document.querySelector('#registerBox').style.display='block';}
function showLogin(){document.querySelector('#registerBox').style.display='none';document.querySelector('#loginBox').style.display='block';}

async function login(){
    let email=document.getElementById('loginEmail').value;
    let password=document.getElementById('loginPass').value;
    let r=await fetch('/api/user/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
    let d=await r.json();
    alert(d.success?'Login Success':'Invalid Credentials');
}

async function register(){
    let name=document.getElementById('regName').value;
    let email=document.getElementById('regEmail').value;
    let password=document.getElementById('regPass').value;
    let r=await fetch('/api/user/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,password})});
    let d=await r.json();
    alert(d.success?'Registered Successfully':'Email already exists');
}
