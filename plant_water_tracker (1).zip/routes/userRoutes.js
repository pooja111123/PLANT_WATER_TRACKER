
const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/register', async(req,res)=>{
    const {name,email,password} = req.body;
    try{
        const user = await User.create({name,email,password});
        res.json({success:true});
    }catch(e){
        res.json({success:false, message:"Email exists"});
    }
});

router.post('/login', async(req,res)=>{
    const {email,password} = req.body;
    const user = await User.findOne({email,password});
    if(user) res.json({success:true});
    else res.json({success:false});
});

module.exports = router;
